You need to have Python 3 installed

Open Command Prompt/Terminal in this folder and run this command
pip install -r requirements.txt

It will install requirements that was used to run this python script.

Features:
- Change Name
- Money
- Persona Points
- Bonds
- Weapons
- Armors
- Accessories
- Consumables
- Recipes
- Cash Mats.
- Skill Cards
- Persona

* For Persona part, open 'Persona List ID.txt' You can use Lucifer or any other Persona. However, you can't register them because of your character's level.

* When clicking the Save Changes button, do not close the window and let it run for a bit then it will close itself. (If you close it or play around with it, it may crash the program.)